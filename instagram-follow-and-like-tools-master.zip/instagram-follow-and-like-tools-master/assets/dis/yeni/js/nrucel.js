function googleTranslateElementInit() {
  new google.translate.TranslateElement({pageLanguage: 'tr', layout: google.translate.TranslateElement.FloatPosition.SIMPLE}, 'google_translate_element');
}