  <main>

    <!-- Home Banner Start -->
    <section class="page-title-section" style="background: #1576c2">
      <div class="container text-center">
          <h1 style="margin: 0 0 20px;font-size: 32px;font-weight: 500;color: #fff;"><?=$blogAdi;?></h1>
      </div>
    </section>
    <!-- / -->

    <!-- Featre -->
    <section id="about" class="section border-bottom">
      <div class="container">
        <div class="row m-45px-b md-m-25px-b">
          <div class="col-md-12">
				      <?=$blogDetay;?>
          </div>
        </div>
      </div> <!-- container -->
    </section>
    <!-- / -->

  </main>
<? include 'slider.php';?>
  