<div class="wrap">
    <section class="app-content">
       <div class="card card-info center">
          </div>
        <div class="row">
            <div class="col-md-8">
                <div class="col-md-12">
            <div class="widget" style="background: #47a9f5;">
                <header class="widget-header">
                    <h4 class="widget-title" style="color: white;">Aktif Araçlar</h4>
                </header>
        </div>
        </div>
            <div class="col-md-6">
                <div id="profile-tabs" class="nav-tabs-horizontal white m-b-lg" style="border-style:solid;border-color: #47a9f5; border-width: 2px;border-radius: 5px">
                    <header class="widget-header">
                        <h4 class="widget-title">Kullanıcı Adı ile Takipçi Gönder</h4>
                    </header>
                    <hr class="widget-separator">
                  <div id="profile-stream">
                            <div class="media stream-post">
                                <div class="media-body">
                                    <p><strong>istediğin hesaba takipçi gönder</strong></p>
                                    <p>Her saat yenilenen kredin kadar, istediğin hesaba kredin kadar takipçi gönderebilirsin. Tek yapman gereken aşağıdaki butona basmak ve çıkan sayfada takipçi atmak istediğin hesabın kullanıcı adını yazmak.</p>
                                    <hr class="widget-separator">
                                    <div class=" m-t-md">
                                        <a href="<?=base_url("panel/takipci")?>" type="button" style="display:block;width:100%;margin-bottom:20px;" class="btn btn-primary begendir">Takipçi Gönder</a>
                                    </div>
                                </div>
                            </div>
                    </div>
                </div>
            </div>


            <div class="col-md-6">
                <div id="profile-tabs" class="nav-tabs-horizontal white m-b-lg" style="border-style:solid;border-color: #47a9f5; border-width: 2px;border-radius: 5px">
                    <header class="widget-header">
                        <h4 class="widget-title">Link ile Beğeni Gönder</h4>
                    </header>
                    <hr class="widget-separator">
                  <div id="profile-stream">
                            <div class="media stream-post">
                                <div class="media-body">
                                    <p><strong>istediğin fotoğrafa beğeni gönder</strong></p>
                                    <p>Her saat yenilenen kredin kadar, istediğin fotoğrafa kredin kadar beğeni gönderebilirsin. Tek yapman gereken aşağıdaki butona basmak ve çıkan sayfada beğeni atmak istediğin fotoğrafın linkini yazmak.</p>
                                    <hr class="widget-separator">
                                    <div class=" m-t-md">
                                        <a href="<?=base_url("panel/begeni")?>" type="button" style="display:block;width:100%;margin-bottom:20px;" class="btn btn-primary begendir">Beğeni Gönder</a>
                                    </div>
                                </div>
                            </div>
                    </div>
                </div>
            </div>
            </div>
            <? include('sidebar.php'); ?>
</div>
    </section>
</div>		